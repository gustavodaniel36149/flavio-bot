# core-util-is

The `util.is*` functions introduced in Node v0.12.
