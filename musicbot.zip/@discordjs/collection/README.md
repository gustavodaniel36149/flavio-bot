# Collection

Utility data structure used in Discord.js.
